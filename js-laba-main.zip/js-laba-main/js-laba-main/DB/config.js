module.exports = {
  host: 'localhost',
  username: 'root', 
  password: 'cryy_me_a_river', 
  database: 'test',
  dialect: 'mysql',
};