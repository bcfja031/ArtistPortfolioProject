const Sequelize = require('sequelize');
const sequelize = new Sequelize('test', 'root', 'cryy_me_a_river', {
    host: 'localhost',
    dialect: 'mysql',
    logging: false
});

module.exports = sequelize;