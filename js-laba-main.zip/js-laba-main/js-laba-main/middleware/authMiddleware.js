const jwt = require('jsonwebtoken');
const { User } = require('../models');

exports.requireAuth = async (req, res, next) => {
    let token;

    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        token = req.headers.authorization.split(' ')[1];
    } else if (req.cookies.token) {
        token = req.cookies.token;
    }

    if (!token) {
        if (req.accepts('html')) { 
            req.session.returnTo = req.originalUrl;
            return res.redirect('/login'); 
        } else {
            return res.status(401).json({ message: 'Not authorized, no token' });
        }
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findByPk(decoded.id, {
            attributes: { exclude: ['password'] }
        });

        if (!user) {
            res.clearCookie('token');
            if (req.accepts('html')) {
                req.session.returnTo = req.originalUrl;
                return res.redirect('/login');
            } else {
                return res.status(401).json({ message: 'Not authorized, user not found' });
            }
        }

        req.user = user; 
        res.locals.user = user; 
        next();
    } catch (error) {
        console.error('Token verification error:', error);
        res.clearCookie('token');
        if (req.accepts('html')) {
            req.session.returnTo = req.originalUrl;
            return res.redirect('/login');
        } else {
            return res.status(401).json({ message: 'Not authorized, token failed' });
        }
    }
};

const setUserContext = async (req, res, next) => {
  let token;
  console.log('[setUserContext] Triggered for path:', req.path);
  if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
    console.log('[setUserContext] Token found in cookies:', token ? 'Yes' : 'No');
  } else if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
    console.log('[setUserContext] Token found in headers:', token ? 'Yes' : 'No');
  } else {
    console.log('[setUserContext] No token found in cookies or headers.');
  }

  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      console.log('[setUserContext] Token decoded:', decoded);
      const user = await User.findByPk(decoded.id, { attributes: { exclude: ['password'] } });
      if (user) {
        req.user = user;
        console.log('[setUserContext] req.user set with ID:', user.id);
      } else {
        console.log('[setUserContext] User not found for decoded ID:', decoded.id);
      }
    } catch (err) {
      console.error('[setUserContext] Error verifying token or finding user:', err.message);
    }
  } else {
    console.log('[setUserContext] No token to process.');
  }
  next();
};

module.exports = {
  requireAuth: exports.requireAuth,
  setUserContext
};