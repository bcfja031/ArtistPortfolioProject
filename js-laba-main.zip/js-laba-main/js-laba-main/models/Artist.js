const { DataTypes, Model } = require('sequelize');
const bcrypt = require('bcryptjs');

module.exports = (sequelize, DataTypes) => {
  class Artist extends Model { 
    static associate(models) {
      Artist.hasMany(models.Picture, {
        foreignKey: 'IDArtist',
        as: 'pictures'
      });
  
      Artist.hasMany(models.Review, {
        foreignKey: 'IDArtist',
        as: 'reviews'
      });
  
      Artist.belongsToMany(models.Gallery, {
        through: models.Exhibition,
        foreignKey: 'IDArtist',
        otherKey: 'IDGallery',
        as: 'galleries'
      });
  
      Artist.belongsToMany(models.Journal, {
        through: models.Publishes,
        foreignKey: 'IDArtist',
        otherKey: 'IDJournal',
        as: 'journals'
      });
  
      Artist.belongsToMany(models.Brand, {
        through: models.Collaborations,
        foreignKey: 'IDArtist',
        otherKey: 'IDBrand',
        as: 'collaboratingBrands'
      });
    }
  }
  
  Artist.init({
    IDArtist: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    FullNameArtist: {
      type: DataTypes.STRING(200),
      allowNull: false
    },
    AgeArtist: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 18,
      validate: {
        min: 18,
        max: 100
      }
    },
    EmailArtist: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true,
        notEmpty: true
      }
    },
    BriefBiography: {
      type: DataTypes.STRING(300),
      allowNull: true
    },
    PhoneNumberArtist: {
      type: DataTypes.STRING(15),
      allowNull: false,
      unique: true,
      validate: {
        notEmpty: true
      }
    },
    PasswordArtist: {
      type: DataTypes.STRING(100),
      allowNull: false,
      validate: {
          notEmpty: true
      }
    }
  }, {
    sequelize,
    modelName: 'Artist',
    tableName: 'Artist',
    timestamps: false,
    hooks: {
      beforeCreate: async (artist) => {
        if (artist.PasswordArtist) {
          const salt = await bcrypt.genSalt(10);
          artist.PasswordArtist = await bcrypt.hash(artist.PasswordArtist, salt);
        }
      },
      beforeUpdate: async (artist) => {
        if (artist.changed('PasswordArtist')) {
          const salt = await bcrypt.genSalt(10);
          artist.PasswordArtist = await bcrypt.hash(artist.PasswordArtist, salt);
        }
      }
    }
  });
  
  return Artist;
}; 