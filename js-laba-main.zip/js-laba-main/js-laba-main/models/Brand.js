'use strict';
const { DataTypes, Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Brand extends Model {
    static associate(models) {
      Brand.belongsToMany(models.Artist, {
        through: models.Collaborations,
        foreignKey: 'IDBrand',
        otherKey: 'IDArtist',
        as: 'artists'
      });
    }
  }
  
  Brand.init({
    IDBrand: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    NameOfCompany: {
      type: DataTypes.STRING(300),
      allowNull: false
    },
    TermsOfAgreement: {
      type: DataTypes.STRING(1000),
      allowNull: false
    },
    TypeOfProduct: {
      type: DataTypes.STRING(150),
      allowNull: true
    },
    Price: {
      type: DataTypes.DECIMAL(19, 4),
      defaultValue: 1000,
      allowNull: true,
      validate: {
        min: 0.01
      }
    }
  }, {
    sequelize,
    modelName: 'Brand',
    tableName: 'Brand',
    timestamps: false
  });
  
  return Brand;
};
