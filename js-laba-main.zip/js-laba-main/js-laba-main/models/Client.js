'use strict';
const { DataTypes, Model } = require('sequelize');

const bcrypt = require('bcrypt');

module.exports = (sequelize, DataTypes) => {
  class Client extends Model {
    static associate(models) {
    }
  
    async comparePassword(candidatePassword) {
        return bcrypt.compare(candidatePassword, this.Password); 
    }
  }
  
  Client.init({
    IDClient: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    FullNameClient: {
      type: DataTypes.STRING(200),
      allowNull: false
    },
    AgeClient: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 18,
      validate: {
        min: 18,
        max: 100
      }
    },
    Password: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    EmailClient: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true,
      }
    },
    PhoneNumberClient: {
      type: DataTypes.STRING(15),
      allowNull: false,
      unique: true,
      validate: {
        is: /^[\d]+$/,
        len: [10, 15]
      }
    }
  }, {
    sequelize,
    modelName: 'Client',
    tableName: 'Client',
    timestamps: false, 
    hooks: {
      beforeCreate: async (client) => {
        if (client.Password) { 
          const salt = await bcrypt.genSalt(10);
          client.Password = await bcrypt.hash(client.Password, salt);
        }
      },
      beforeUpdate: async (client) => {
        if (client.changed('Password') && client.Password) {
          const salt = await bcrypt.genSalt(10);
          client.Password = await bcrypt.hash(client.Password, salt);
        }
      }
    }
  });
  
  return Client;
};
