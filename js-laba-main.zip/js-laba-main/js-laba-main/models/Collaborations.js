'use strict';
const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class Collaborations extends Model {
    static associate(models) {
      Collaborations.belongsTo(models.Artist, {
        foreignKey: 'IDArtist',
        as: 'artist'
      });
      Collaborations.belongsTo(models.Brand, {
        foreignKey: 'IDBrand',
        as: 'brand'
      });
    }
  }

  Collaborations.init({
    IDCollaboration: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    IDArtist: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Artist',
        key: 'IDArtist'
      },
      onDelete: 'CASCADE'
    },
    IDBrand: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Brand',
        key: 'IDBrand'
      },
      onDelete: 'CASCADE'
    }
  }, {
    sequelize,
    modelName: 'Collaborations',
    tableName: 'Collaborations',
    timestamps: false
  });

  return Collaborations;
};