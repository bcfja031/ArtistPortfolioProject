'use strict';
const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class Exhibition extends Model {
    static associate(models) {
      Exhibition.belongsTo(models.Gallery, {
        foreignKey: 'IDGallery',
        as: 'gallery'
      });

      Exhibition.belongsTo(models.Artist, {
        foreignKey: 'IDArtist',
        as: 'artist'
      });
    }
  }

  Exhibition.init({
    IDExhibition: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    IDGallery: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Gallery',
        key: 'IDGallery'
      },
      onDelete: 'CASCADE'
    },
    IDArtist: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Artist',
        key: 'IDArtist'
      },
      onDelete: 'CASCADE'
    }
  }, {
    sequelize,
    modelName: 'Exhibition',
    tableName: 'Exhibition',
    timestamps: false
  });

  return Exhibition;
};
