'use strict';
const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class Gallery extends Model {
    static associate(models) {
      Gallery.belongsToMany(models.Artist, {
        through: models.Exhibition,
        foreignKey: 'IDGallery',
        otherKey: 'IDArtist',
        as: 'exhibitingArtists'
      });

      Gallery.hasMany(models.Exhibition, { 
        foreignKey: 'IDGallery',
        as: 'exhibitions'
      });
    }
  }
S
  Gallery.init({
    IDGallery: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    NameOfGallery: {
      type: DataTypes.STRING(200),
      allowNull: false,
    },
    GalleryStake: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      defaultValue: 2.0
    }
  }, {
    sequelize,
    modelName: 'Gallery',
    tableName: 'Gallery', 
    timestamps: false
  });

  return Gallery;
};
