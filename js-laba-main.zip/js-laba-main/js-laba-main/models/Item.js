const pool = require('../DB/config.js');

class Item {
    static async getAll() {
        const [rows] = await pool.query('SELECT * FROM items');
        return rows;
    }

    static async getById(id) {
        const [rows] = await pool.query('SELECT * FROM items WHERE id = ?', [id]);
        return rows[0];
    }

    static async create({ name, description }) {
        const [result] = await pool.query(
            'INSERT INTO items (name, description) VALUES (?, ?)',
            [name, description]
        );
        return result.insertId;
    }

    static async update(id, { name, description }) {
        await pool.query(
            'UPDATE items SET name = ?, description = ? WHERE id = ?',
            [name, description, id]
        );
    }

    static async delete(id) {
        await pool.query('DELETE FROM items WHERE id = ?', [id]);
    }
}

module.exports = Item;