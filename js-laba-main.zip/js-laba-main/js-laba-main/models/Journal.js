'use strict';
const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class Journal extends Model {
    static associate(models) {
    }
  }

  Journal.init({
    IDJournal: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    NameOfJournal: {
      type: DataTypes.STRING(200),
      allowNull: false,
    },
    JournalRequirements: {
      type: DataTypes.STRING(400),
      allowNull: true
    },
    JournalStake: {
      type: DataTypes.DECIMAL(10,2),
      allowNull: true,
      defaultValue: 2.0
    }
  }, {
    sequelize,
    modelName: 'Journal',
    tableName: 'Journal',
    timestamps: false
  });

  return Journal;
};
