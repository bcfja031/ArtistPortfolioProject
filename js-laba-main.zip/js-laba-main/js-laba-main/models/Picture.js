'use strict';
const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class Picture extends Model {
    static associate(models) {
      Picture.belongsTo(models.Artist, {
        foreignKey: 'IDArtist',
        as: 'artist',
        onDelete: 'CASCADE'
      });
    }
  }

  Picture.init({
    IDPicture: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    NameOfPicture: {
      type: DataTypes.STRING(150),
      allowNull: false
    },
    DescriptionOfPicture: { 
      type: DataTypes.STRING(300),
      allowNull: true
    },
    ConditionPictures: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    Materials: {
      type: DataTypes.STRING(200),
      allowNull: true 
    },
    Price: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
      defaultValue: 1000.00,
      validate: {
        isDecimal: true,
        min: 0.01
      }
    },
    YearOfDrawing: {
      type: DataTypes.DATEONLY,
      allowNull: true
    },
    StyleOfDrawing: {
      type: DataTypes.STRING(200),
      allowNull: true
    },
    IDArtist: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Artist',
        key: 'IDArtist'
      }
    }
  }, {
    sequelize,
    modelName: 'Picture',
    tableName: 'Pictures',
    timestamps: false
  });

  return Picture;
};
