'use strict';
const { DataTypes, Model } = require('sequelize');

module.exports = (sequelize) => {
  class Publishes extends Model {
    static associate(models) {
      Publishes.belongsTo(models.Journal, {
        foreignKey: 'IDJournal',
        as: 'journal'
      });

      Publishes.belongsTo(models.Artist, {
        foreignKey: 'IDArtist',
        as: 'artist'
      });
    }
  }

  Publishes.init({
    IDPublish: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    IDJournal: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Journal',
        key: 'IDJournal'
      },
      onDelete: 'CASCADE'
    },
    IDArtist: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Artist',
        key: 'IDArtist'
      },
      onDelete: 'CASCADE'
    }
  }, {
    sequelize,
    modelName: 'Publishes',
    tableName: 'Publishes',
    timestamps: false
  });

  return Publishes;
};