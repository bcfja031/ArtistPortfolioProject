'use strict';
const { DataTypes, Model } = require('sequelize');

module.exports = (sequelize) => {
  class Review extends Model {
    static associate(models) {
      Review.belongsTo(models.Client, {
        foreignKey: 'IDClient',
        as: 'client',
        onDelete: 'CASCADE'
      });

      Review.belongsTo(models.Artist, {
        foreignKey: 'IDArtist',
        as: 'artist',
        onDelete: 'CASCADE'
      });
    }
  }

  Review.init({
    IDReview: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    IDArtist: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Artist',
        key: 'IDArtist'
      }
    },
    IDClient: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Client',
        key: 'IDClient'
      }
    },
    Comment: {
      type: DataTypes.STRING(500),
      allowNull: true
    }
  }, {
    sequelize,
    modelName: 'Review',
    tableName: 'Review',
    timestamps: false
  });

  return Review;
};
