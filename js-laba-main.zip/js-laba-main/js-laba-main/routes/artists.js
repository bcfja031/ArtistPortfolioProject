const express = require('express');
const router = express.Router();
const db = require('../models');
const bcrypt = require('bcryptjs');
const { requireAuth } = require('../middleware/authMiddleware');

router.get('/', async (req, res, next) => {
  try {
    const artists = await db.Artist.findAll({
    });
    res.render('artists/index', { 
      title: 'Artists List',
      artists: artists 
    });
  } catch (error) {
    console.error('Error fetching artists:', error);
    next(error); 
  }
});

router.get('/new', requireAuth, (req, res) => {
  res.render('artists/new', { title: 'Add New Artist', formData: {}, errors: [] });
});

router.post('/', requireAuth, async (req, res, next) => {
  console.log('--- New Artist POST Request ---'); 
  console.log('req.body received:', req.body); 

  try {
    const { 
      FullNameArtist, 
      EmailArtist, 
      PasswordArtist, 
      BriefBiography, 
      DateOfBirth, 
      Nationality,
      AgeArtist,
      PhoneNumberArtist 
    } = req.body;

    console.log('Extracted DateOfBirth from req.body:', DateOfBirth);
    console.log('Extracted Nationality from req.body:', Nationality);

    const artistData = {
      FullNameArtist,
      EmailArtist,
      PasswordArtist,
      BriefBiography: BriefBiography || null,
      DateOfBirth: DateOfBirth && DateOfBirth.trim() !== '' ? DateOfBirth : null, 
      Nationality: Nationality && Nationality.trim() !== '' ? Nationality : null, 
      AgeArtist: AgeArtist ? parseInt(AgeArtist) : null,
      PhoneNumberArtist: PhoneNumberArtist || null
    };

    console.log('Data being passed to Artist.create():', artistData);

    await db.Artist.create(artistData);
    console.log('--- Artist creation successful ---');
    res.redirect('/artists');
  } catch (error) {
    console.error('--- Error creating artist ---:', error);
    if (error.name === 'SequelizeValidationError' || error.name === 'SequelizeUniqueConstraintError') {
      const errors = error.errors.map(err => err.message);
      res.status(400).render('artists/new', {
        title: 'Add New Artist',
        errors: errors,
        formData: req.body 
      });
    } else {
      next(error);
    }
  }
});

router.get('/:id/edit', requireAuth, async (req, res, next) => {
  try {
    const artist = await db.Artist.findByPk(req.params.id);
    if (artist) {
      if (artist.DateOfBirth) {
        const date = new Date(artist.DateOfBirth);
        const year = date.getFullYear();
        const month = ('0' + (date.getMonth() + 1)).slice(-2);
        const day = ('0' + date.getDate()).slice(-2);
        artist.formattedDateOfBirth = `${year}-${month}-${day}`;
      }
      res.render('artists/edit', { title: 'Edit Artist', artist: artist, errors: [] });
    } else {
      const err = new Error('Artist Not Found');
      err.status = 404;
      next(err);
    }
  } catch (error) {
    next(error);
  }
});

router.post('/:id', requireAuth, async (req, res, next) => {
  try {
    const artist = await db.Artist.findByPk(req.params.id);
    if (artist) {
      const updateData = { ...req.body };
      if (updateData.DateOfBirth === '') {
        updateData.DateOfBirth = null; 
      }
      if (updateData.PasswordArtist) {
        updateData.PasswordArtist = await bcrypt.hash(updateData.PasswordArtist, 10);
      } else {
        delete updateData.PasswordArtist;
      }

      await artist.update(updateData);
      res.redirect('/artists');
    } else {
      const err = new Error('Artist Not Found');
      err.status = 404;
      next(err);
    }
  } catch (error) {
    if (error.name === 'SequelizeValidationError' || error.name === 'SequelizeUniqueConstraintError') {
      const artist = await db.Artist.findByPk(req.params.id); 
      if (artist.DateOfBirth) {
        const date = new Date(artist.DateOfBirth);
        const year = date.getFullYear();
        const month = ('0' + (date.getMonth() + 1)).slice(-2);
        const day = ('0' + date.getDate()).slice(-2);
        artist.formattedDateOfBirth = `${year}-${month}-${day}`;
      }
      return res.status(400).render('artists/edit', {
        title: 'Edit Artist',
        artist: { ...artist.get({ plain: true }), ...req.body }, 
        errors: error.errors.map(e => e.message)
      });
    }
    next(error);
  }
});

router.post('/:id/delete', requireAuth, async (req, res, next) => {
  try {
    const artist = await db.Artist.findByPk(req.params.id);
    if (artist) {
      await artist.destroy();
      res.redirect('/artists');
    } else {
      const err = new Error('Artist Not Found');
      err.status = 404;
      next(err);
    }
  } catch (error) {
    next(error);
  }
});

module.exports = router;