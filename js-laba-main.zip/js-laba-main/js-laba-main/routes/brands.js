const express = require('express');
const router = express.Router();
const db = require('../models');
const createError = require('http-errors');
const { requireAuth } = require('../middleware/authMiddleware');

router.get('/', async (req, res, next) => {
  try {
    const brands = await db.Brand.findAll({
      order: [['NameOfCompany', 'ASC']]
    });

    res.render('brands/index', {
      title: 'Brands List',
      brands: brands,
      user: req.user,
      query: req.query
    });
  } catch (error) {
    console.error('Error fetching brands:', error);
    next(error);
  }
});

router.get('/new', requireAuth, (req, res) => {
  res.render('brands/new', {
    title: 'Add New Brand',
    user: req.user,
    brand: {},
    errors: []
  });
});

// POST create new brand
router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { NameOfCompany, BrandHistory, TermsOfAgreement, TypeOfProduct, Price } = req.body;

    const errors = [];
    if (!NameOfCompany || NameOfCompany.trim() === '') {
       errors.push({ message: 'Company name is required.' }); // Updated message
    }
    if (!TermsOfAgreement || TermsOfAgreement.trim() === '') {
       errors.push({ message: 'Terms of Agreement is required.' });
    }

    if (errors.length > 0) {
        return res.render('brands/new', {
            title: 'Add New Brand',
            user: req.user,
            brand: req.body,
            errors: errors
        });
    }

    const newBrand = await db.Brand.create({
      NameOfCompany: NameOfCompany.trim(),
      BrandHistory: BrandHistory ? BrandHistory.trim() : null,
      TermsOfAgreement: TermsOfAgreement.trim(),
      TypeOfProduct: TypeOfProduct ? TypeOfProduct.trim() : null,
      Price: Price ? parseFloat(Price) : null
    });

    res.redirect('/brands?message=Brand+created+successfully');
  } catch (error) {
    console.error('Error creating brand:', error);
    let errorMessage = 'Error creating brand. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'A brand with this name already exists.';
    }

    res.render('brands/new', {
      title: 'Add New Brand',
      user: req.user,
      brand: { NameOfCompany: req.body.NameOfCompany, BrandHistory: req.body.BrandHistory, TermsOfAgreement: req.body.TermsOfAgreement, TypeOfProduct: req.body.TypeOfProduct, Price: req.body.Price },
      errors: [{ message: errorMessage }]
    });
  }
});

// GET form to edit brand
router.get('/:id/edit', requireAuth, async (req, res, next) => {
  try {
    const brand = await db.Brand.findByPk(req.params.id);
    if (!brand) {
      return res.status(404).render('error', { message: 'Brand not found', error: { status: 404 } });
    }
    res.render('brands/edit', {
      title: 'Edit Brand',
      brand: brand,
      errors: [],
      user: req.user
    });
  } catch (error) {
    console.error('Error fetching brand for edit:', error);
    next(error);
  }
});

// POST update brand
router.post('/:id/update', requireAuth, async (req, res, next) => {
  try {
    const brandId = req.params.id;
    const { NameOfCompany, BrandHistory, TermsOfAgreement, TypeOfProduct, Price } = req.body;

    const brandToUpdate = await db.Brand.findByPk(brandId);

    if (!brandToUpdate) {
      return res.status(404).render('error', { message: 'Brand not found for update.', error: { status: 404 }});
    }

    // Basic validation
    const errors = [];
    if (!NameOfCompany || NameOfCompany.trim() === '') {
      errors.push({ message: 'Company Name is required.' }); // Updated message
    }
    if (!TermsOfAgreement || TermsOfAgreement.trim() === '') {
       errors.push({ message: 'Terms of Agreement is required.' });
    }

    if (errors.length > 0) {
        return res.render('brands/edit', {
            title: 'Edit Brand',
            brand: { ...brandToUpdate.get({ plain: true }), NameOfCompany, BrandHistory, TermsOfAgreement, TypeOfProduct, Price },
            errors: errors,
            user: req.user
        });
    }

    brandToUpdate.NameOfCompany = NameOfCompany.trim();
    brandToUpdate.BrandHistory = BrandHistory ? BrandHistory.trim() : null;
    brandToUpdate.TermsOfAgreement = TermsOfAgreement.trim();
    brandToUpdate.TypeOfProduct = TypeOfProduct ? TypeOfProduct.trim() : null;
    brandToUpdate.Price = Price ? parseFloat(Price) : null;

    await brandToUpdate.save();
    res.redirect('/brands?message=Brand+updated+successfully');
  } catch (error) {
    console.error('Error updating brand:', error);
    let errorMessage = 'Error updating brand. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'A brand with this name already exists.';
    }

    try {
        const brand = await db.Brand.findByPk(req.params.id);
        res.render('brands/edit', {
           title: 'Edit Brand',
           brand: { ...brand.get({ plain: true }), NameOfCompany: req.body.NameOfCompany, BrandHistory: req.body.BrandHistory, TermsOfAgreement: req.body.TermsOfAgreement, TypeOfProduct: req.body.TypeOfProduct, Price: req.body.Price },
           errors: [{ message: errorMessage }],
           user: req.user
         });
    } catch (fetchError) {
        console.error('Error fetching data after update error:', fetchError);
        next(error);
    }
  }
});

// POST delete brand
router.post('/:id/delete', requireAuth, async (req, res, next) => {
  try {
    const brandId = req.params.id;
    const brandToDelete = await db.Brand.findByPk(brandId);

    if (!brandToDelete) {
      return res.status(404).render('error', { message: 'Brand not found for deletion.', error: { status: 404 }});
    }

    await brandToDelete.destroy();
    res.redirect('/brands?message=Brand+deleted+successfully');
  } catch (error) {
    console.error('Error deleting brand:', error);
    next(error);
  }
});

module.exports = router;