const express = require('express');
const router = express.Router();
const db = require('../models');
const createError = require('http-errors');
const { requireAuth } = require('../middleware/authMiddleware');

router.get('/', async (req, res, next) => {
  try {
    const clients = await db.Client.findAll({
      order: [['FullNameClient', 'ASC']]
    });

    res.render('clients/index', {
      title: 'Clients List',
      clients: clients,
      user: req.user,
      query: req.query
    });
  } catch (error) {
    console.error('Error fetching clients:', error);
    next(error);
  }
});

router.get('/new', requireAuth, (req, res) => {
  res.render('clients/new', {
    title: 'Add New Client',
    user: req.user,
    client: {},
    errors: []
  });
});

router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { FullNameClient, EmailClient, PasswordClient, PhoneNumberClient } = req.body;

    const errors = [];
    if (!FullNameClient || FullNameClient.trim() === '') {
       errors.push({ message: 'Full Name is required.' });
    }
    if (!EmailClient || EmailClient.trim() === '') {
        errors.push({ message: 'Email is required.' });
    }
     if (!PasswordClient || PasswordClient.trim() === '') {
        errors.push({ message: 'Password is required.' });
    }


    if (errors.length > 0) {
        return res.render('clients/new', {
            title: 'Add New Client',
            user: req.user,
            client: req.body,
            errors: errors
        });
    }

    const newClient = await db.Client.create({
      FullNameClient: FullNameClient.trim(),
      EmailClient: EmailClient.trim(),
      PasswordClient: PasswordClient.trim(),
      PhoneNumberClient: PhoneNumberClient ? PhoneNumberClient.trim() : null
    });

    res.redirect('/clients?message=Client+created+successfully');
  } catch (error) {
    console.error('Error creating client:', error);
    let errorMessage = 'Error creating client. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'Client with this email already exists.';
    }

    res.render('clients/new', {
      title: 'Add New Client',
      user: req.user,
      client: req.body,
      errors: [{ message: errorMessage }]
    });
  }
});

router.get('/:id/edit', requireAuth, async (req, res, next) => {
  try {
    const client = await db.Client.findByPk(req.params.id);
    if (!client) {
      return res.status(404).render('error', { message: 'Client not found', error: { status: 404 } });
    }
    res.render('clients/edit', {
      title: 'Edit Client',
      client: client,
      errors: [],
      user: req.user
    });
  } catch (error) {
    console.error('Error fetching client for edit:', error);
    next(error);
  }
});

router.post('/:id/update', requireAuth, async (req, res, next) => {
  try {
    const clientId = req.params.id;
    const { FullNameClient, EmailClient, PasswordClient, PhoneNumberClient } = req.body;

    const clientToUpdate = await db.Client.findByPk(clientId);

    if (!clientToUpdate) {
      return res.status(404).render('error', { message: 'Client not found for update.', error: { status: 404 }});
    }

    const errors = [];
    if (!FullNameClient || FullNameClient.trim() === '') {
       errors.push({ message: 'Full Name is required.' });
    }
    if (!EmailClient || EmailClient.trim() === '') {
        errors.push({ message: 'Email is required.' });
    }

    if (errors.length > 0) {
        return res.render('clients/edit', {
            title: 'Edit Client',
            client: { ...clientToUpdate.get({ plain: true }), FullNameClient, EmailClient },
            errors: errors,
            user: req.user
        });
    }

    clientToUpdate.FullNameClient = FullNameClient.trim();
    clientToUpdate.EmailClient = EmailClient.trim();
    clientToUpdate.PhoneNumberClient = PhoneNumberClient ? PhoneNumberClient.trim() : null;

    if (PasswordClient && PasswordClient.trim() !== '') {
        clientToUpdate.PasswordClient = PasswordClient.trim();
    }


    await clientToUpdate.save();
    res.redirect('/clients?message=Client+updated+successfully');
  } catch (error) {
    console.error('Error updating client:', error);
    let errorMessage = 'Error updating client. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'Client with this email already exists.';
    }

    try {
        const client = await db.Client.findByPk(req.params.id);
        res.render('clients/edit', {
           title: 'Edit Client',
           client: { ...client.get({ plain: true }), FullNameClient: req.body.FullNameClient, EmailClient: req.body.EmailClient },
           errors: [{ message: errorMessage }],
           user: req.user
         });
    } catch (fetchError) {
        console.error('Error fetching data after update error:', fetchError);
        next(error);
    }
  }
});

router.post('/:id/delete', requireAuth, async (req, res, next) => {
  try {
    const clientId = req.params.id;
    const clientToDelete = await db.Client.findByPk(clientId);

    if (!clientToDelete) {
      return res.status(404).render('error', { message: 'Client not found for deletion.', error: { status: 404 }});
    }

    await clientToDelete.destroy();
    res.redirect('/clients?message=Client+deleted+successfully');
  } catch (error) {
    console.error('Error deleting client:', error);
    next(error);
  }
});

module.exports = router;