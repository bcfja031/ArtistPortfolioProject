const express = require('express');
const router = express.Router();
const db = require('../models');
const createError = require('http-errors');
const { requireAuth } = require('../middleware/authMiddleware');

router.get('/', async (req, res, next) => {
  try {
    const collaborations = await db.Collaborations.findAll({
      include: [
        { model: db.Artist, as: 'artist', attributes: ['FullNameArtist'] },
        { model: db.Brand, as: 'brand', attributes: ['NameOfCompany'] }
      ],
      order: [['IDCollaboration', 'ASC']]
    });
    res.render('collaborations/index', {
      title: 'Collaborations List',
      collaborations: collaborations,
      user: req.user,
      query: req.query 
    });
  } catch (error) {
    console.error('Error fetching collaborations:', error);
    next(error);
  }
});

router.get('/new', requireAuth, async (req, res) => {
  try {
    const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
    const brands = await db.Brand.findAll({ order: [['NameOfCompany', 'ASC']] });
    res.render('collaborations/new', {
      title: 'Add New Collaboration',
      user: req.user,
      collaboration: {},
      errors: [],
      artists: artists,
      brands: brands
    });
  } catch (error) {
    console.error('Error fetching data for new collaboration form:', error);
    res.render('collaborations/new', {
      title: 'Add New Collaboration',
      user: req.user,
      collaboration: {},
      errors: [{ message: 'Could not load required data for the form.' }],
      artists: [],
      brands: []
    });
  }
});

router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { IDArtist, IDBrand } = req.body;

    const errors = [];
    if (!IDArtist) {
       errors.push({ message: 'Artist is required.' });
    }
    if (!IDBrand) {
        errors.push({ message: 'Brand is required.' });
    }

    if (errors.length > 0) {
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        const brands = await db.Brand.findAll({ order: [['NameOfCompany', 'ASC']] });
        return res.render('collaborations/new', {
            title: 'Add New Collaboration',
            user: req.user,
            collaboration: req.body,
            errors: errors,
            artists: artists,
            brands: brands
        });
    }

    const newCollaboration = await db.Collaborations.create({
      IDArtist: IDArtist,
      IDBrand: IDBrand
    });

    res.redirect('/collaborations?message=Collaboration+created+successfully');
  } catch (error) {
    console.error('Error creating collaboration:', error);
    let errorMessage = 'Error creating collaboration. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'This collaboration already exists.';
    }

    try {
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        const brands = await db.Brand.findAll({ order: [['NameOfCompany', 'ASC']] });
        res.render('collaborations/new', {
          title: 'Add New Collaboration',
          user: req.user,
          collaboration: req.body,
          errors: [{ message: errorMessage }],
          artists: artists,
          brands: brands
        });
    } catch (fetchError) {
        console.error('Error fetching data after creation error:', fetchError);
        next(error);
    }
  }
});

router.get('/:id/edit', requireAuth, async (req, res, next) => {
  try {
    const collaboration = await db.Collaborations.findByPk(req.params.id);
    if (!collaboration) {
      return res.status(404).render('error', { message: 'Collaboration not found', error: { status: 404 } });
    }
    const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
    const brands = await db.Brand.findAll({ order: [['NameOfCompany', 'ASC']] });
    res.render('collaborations/edit', {
      title: 'Edit Collaboration',
      collaboration: collaboration,
      errors: [],
      user: req.user,
      artists: artists,
      brands: brands
    });
  } catch (error) {
    console.error('Error fetching collaboration for edit:', error);
    next(error);
  }
});

router.post('/:id/update', requireAuth, async (req, res, next) => {
  try {
    const collaborationId = req.params.id;
    const { IDArtist, IDBrand } = req.body;

    const collaborationToUpdate = await db.Collaborations.findByPk(collaborationId);

    if (!collaborationToUpdate) {
      return res.status(404).render('error', { message: 'Collaboration not found for update.', error: { status: 404 }});
    }

    const errors = [];
    if (!IDArtist) {
      errors.push({ message: 'Artist is required.' });
    }
    if (!IDBrand) {
        errors.push({ message: 'Brand is required.' });
    }

    if (errors.length > 0) {
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        const brands = await db.Brand.findAll({ order: [['NameOfCompany', 'ASC']] });
        return res.render('collaborations/edit', {
            title: 'Edit Collaboration',
            collaboration: { ...collaborationToUpdate.get({ plain: true }), IDArtist, IDBrand },
            errors: errors,
            user: req.user,
            artists: artists,
            brands: brands
        });
    }

    collaborationToUpdate.IDArtist = IDArtist;
    collaborationToUpdate.IDBrand = IDBrand;

    await collaborationToUpdate.save();
    res.redirect('/collaborations?message=Collaboration+updated+successfully');
  } catch (error) {
    console.error('Error updating collaboration:', error);
    let errorMessage = 'Error updating collaboration. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'This collaboration already exists.';
    }

    try {
        const collaboration = await db.Collaborations.findByPk(req.params.id);
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        const brands = await db.Brand.findAll({ order: [['NameOfCompany', 'ASC']] });
        res.render('collaborations/edit', {
           title: 'Edit Collaboration',
           collaboration: { ...collaboration.get({ plain: true }), IDArtist: req.body.IDArtist, IDBrand: req.body.IDBrand },
           errors: [{ message: errorMessage }],
           user: req.user,
           artists: artists,
           brands: brands
         });
    } catch (fetchError) {
        console.error('Error fetching data after update error:', fetchError);
        next(error);
    }
  }
});


router.post('/:id/delete', requireAuth, async (req, res, next) => {
  try {
    const collaborationId = req.params.id;
    const collaborationToDelete = await db.Collaborations.findByPk(collaborationId);

    if (!collaborationToDelete) {
      return res.status(404).render('error', { message: 'Collaboration not found for deletion.', error: { status: 404 }});
    }

    await collaborationToDelete.destroy();
    res.redirect('/collaborations?message=Collaboration+deleted+successfully');
  } catch (error) {
    console.error('Error deleting collaboration:', error);
    next(error);
  }
});

module.exports = router;