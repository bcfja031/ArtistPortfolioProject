const express = require('express');
const router = express.Router();
const db = require('../models');
const createError = require('http-errors');
const { requireAuth } = require('../middleware/authMiddleware');

router.get('/', async (req, res, next) => {
  try {
    const exhibitions = await db.Exhibition.findAll({
      include: [
        { model: db.Artist, as: 'artist' },
        { model: db.Gallery, as: 'gallery' }
      ]
    });
    res.render('exhibitions/index', {
      title: 'Exhibitions List',
      exhibitions: exhibitions,
      user: req.user,
      query: req.query
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:id/edit', requireAuth, async (req, res, next) => {
  try {
    const exhibition = await db.Exhibition.findByPk(req.params.id, {
      include: [
        { model: db.Artist, as: 'artist' },
        { model: db.Gallery, as: 'gallery' }
      ]
    });
    if (!exhibition) {
      return res.status(404).render('error', { message: 'Exhibition not found', error: { status: 404 } });
    }
    const galleries = await db.Gallery.findAll();
    const artists = await db.Artist.findAll();
    res.render('exhibitions/edit', {
      title: 'Edit Exhibition',
      exhibition: exhibition,
      errorMessage: null,
      user: req.user,
      galleries: galleries,
      artists: artists
    });
  } catch (error) {
    next(error);
  }
});

router.get('/new', requireAuth, async (req, res) => {
  try {
    const galleries = await db.Gallery.findAll();
    const artists = await db.Artist.findAll();
    res.render('exhibitions/new', {
      title: 'Add New Exhibition',
      user: req.user,
      exhibition: {},
      errors: [],
      galleries: galleries,
      artists: artists
    });
  } catch (error) {
    console.error('Error fetching data for new exhibition form:', error);
    res.render('exhibitions/new', {
      title: 'Add New Exhibition',
      user: req.user,
      exhibition: {},
      errors: [{ message: 'Could not load required data for the form.' }],
      galleries: [],
      artists: []
    });
  }
});

router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { IDGallery, IDArtist } = req.body;

    const errors = [];
    if (!IDGallery) {
        errors.push({ message: 'Gallery is required.' });
    }
    if (!IDArtist) {
        errors.push({ message: 'Artist is required.' });
    }

    if (errors.length > 0) {
        const galleries = await db.Gallery.findAll();
        const artists = await db.Artist.findAll();
        return res.render('exhibitions/new', {
            title: 'Add New Exhibition',
            user: req.user,
            exhibition: req.body,
            errors: errors,
            galleries: galleries,
            artists: artists
        });
    }

    const newExhibition = await db.Exhibition.create({
      IDGallery: IDGallery,
      IDArtist: IDArtist
    });

    res.redirect('/exhibitions?message=Exhibition+created+successfully');
  } catch (error) {
    console.error('Error creating exhibition:', error);
    let errorMessage = 'Error creating exhibition. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'An exhibition with this Gallery and/or Artist combination already exists.';
    }

    try {
        const galleries = await db.Gallery.findAll();
        const artists = await db.Artist.findAll();
        res.render('exhibitions/new', {
          title: 'Add New Exhibition',
          user: req.user,
          exhibition: req.body,
          errors: [{ message: errorMessage }],
          galleries: galleries,
          artists: artists
        });
    } catch (fetchError) {
        console.error('Error fetching data after creation error:', fetchError);
        next(error);
    }
  }
});

router.post('/:id/update', requireAuth, async (req, res, next) => {
  try {
    const exhibitionId = req.params.id;
    const { IDGallery, IDArtist } = req.body;

    const exhibitionToUpdate = await db.Exhibition.findByPk(exhibitionId);

    if (!exhibitionToUpdate) {
      return res.status(404).render('error', { message: 'Exhibition not found for update.', error: { status: 404 }});
    }

    const errors = [];
    if (!IDGallery) {
        errors.push({ message: 'Gallery is required.' });
    }
    if (!IDArtist) {
        errors.push({ message: 'Artist is required.' });
    }

    if (errors.length > 0) {
        const galleries = await db.Gallery.findAll();
        const artists = await db.Artist.findAll();
        return res.render('exhibitions/edit', {
            title: 'Edit Exhibition',
            exhibition: { ...exhibitionToUpdate.get({ plain: true }), IDGallery, IDArtist },
            errors: errors,
            user: req.user,
            galleries: galleries,
            artists: artists
        });
    }

    exhibitionToUpdate.IDGallery = IDGallery;
    exhibitionToUpdate.IDArtist = IDArtist;

    await exhibitionToUpdate.save();
    res.redirect('/exhibitions?message=Exhibition+updated+successfully');
  } catch (error) {
    console.error('Error updating exhibition:', error);
    try {
        const galleries = await db.Gallery.findAll();
        const artists = await db.Artist.findAll();
        res.render('exhibitions/edit', {
           title: 'Edit Exhibition',
           exhibition: { ...exhibitionToUpdate.get({ plain: true }), IDGallery: req.body.IDGallery, IDArtist: req.body.IDArtist },
           errors: [{ message: 'Error updating exhibition. Please try again.' }],
           user: req.user,
           galleries: galleries,
           artists: artists
         });
    } catch (fetchError) {
        console.error('Error fetching data after update error:', fetchError);
        next(error);
    }
  }
});

router.post('/:id/delete', requireAuth, async (req, res, next) => {
  try {
    const exhibitionId = req.params.id;
    const exhibitionToDelete = await db.Exhibition.findByPk(exhibitionId);

    if (!exhibitionToDelete) {
      return res.status(404).render('error', { message: 'Exhibition not found for deletion.', error: { status: 404 }});
    }

    await exhibitionToDelete.destroy();
    res.redirect('/exhibitions?message=Exhibition+deleted+successfully');
  } catch (error) {
    console.error('Error deleting exhibition:', error);
    next(error);
  }
});

module.exports = router;