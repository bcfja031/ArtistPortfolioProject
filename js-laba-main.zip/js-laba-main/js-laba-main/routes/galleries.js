const express = require('express');
const router = express.Router();
const db = require('../models');
const createError = require('http-errors'); 
const { requireAuth } = require('../middleware/authMiddleware');

router.get('/', async (req, res, next) => {
  try {
    const galleries = await db.Gallery.findAll({
      order: [['NameOfGallery', 'ASC']]
    });
    res.render('galleries/index', {
      title: 'Galleries List',
      galleries: galleries,
      user: req.user,
      query: req.query
    });
  } catch (error) {
    next(error);
  }
});

router.get('/new', requireAuth, (req, res) => {
  res.render('galleries/new', {
    title: 'Add New Gallery',
    user: req.user, 
    gallery: {},
    errors: [] 
  });
});

router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { NameOfGallery, GalleryStake } = req.body;
    
    if (!NameOfGallery || NameOfGallery.trim() === '') {
      return res.render('galleries/new', {
        title: 'Add New Gallery',
        user: req.user,
        gallery: { NameOfGallery, GalleryStake }, 
        errorMessage: 'Gallery name is required.',
        query: req.query
      });
    }

    const newGallery = await db.Gallery.create({
      NameOfGallery: NameOfGallery.trim(),
      GalleryStake: GalleryStake ? parseFloat(GalleryStake) : null 
    });

    res.redirect('/galleries?message=Gallery+created+successfully'); 
  } catch (error) {
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.render('galleries/new', {
        title: 'Add New Gallery',
        user: req.user,
        gallery: { NameOfGallery: req.body.NameOfGallery, GalleryStake: req.body.GalleryStake },
        errorMessage: `Gallery with name "${req.body.NameOfGallery}" already exists.`,
        query: req.query
      });
    }
    next(error); 
  }
});

router.get('/:id/edit', requireAuth, async (req, res, next) => {
  try {
    const gallery = await db.Gallery.findByPk(req.params.id);
    if (!gallery) {
      return res.status(404).render('error', { message: 'Gallery not found', error: { status: 404 } });
    }
    res.render('galleries/edit', { title: 'Edit Gallery', gallery: gallery, errorMessage: null });
  } catch (error) {
    next(error);
  }
});

router.post('/:id/update', requireAuth, async (req, res, next) => {
  try {
    const galleryId = req.params.id;
    const { NameOfGallery, GalleryStake } = req.body;
    const galleryToUpdate = await db.Gallery.findByPk(galleryId);

    if (!galleryToUpdate) {
      return res.status(404).render('error', { message: 'Gallery not found for update.', error: { status: 404 }});
    }

    if (!NameOfGallery || NameOfGallery.trim() === '') {
      return res.render('galleries/edit', {
        title: 'Edit Gallery',
        gallery: { ...galleryToUpdate.get({ plain: true }), NameOfGallery, GalleryStake },
        errorMessage: 'Gallery Name is required.'
      });
    }
    let stakeValue = GalleryStake ? parseFloat(GalleryStake) : null;
    if (GalleryStake && (isNaN(stakeValue) || stakeValue < 0 || stakeValue > 100)) {
     return res.render('galleries/edit', {
       title: 'Edit Gallery',
       gallery: { ...galleryToUpdate.get({ plain: true }), NameOfGallery, GalleryStake },
       errorMessage: 'Gallery Stake must be a number between 0 and 100, or blank.'
     });
    }

    galleryToUpdate.NameOfGallery = NameOfGallery.trim();
    galleryToUpdate.GalleryStake = stakeValue;
    
    await galleryToUpdate.save();
    res.redirect('/galleries?message=Gallery+updated+successfully');
  } catch (error) {
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.render('galleries/edit', {
        title: 'Edit Gallery',
        gallery: { IDGallery: req.params.id, NameOfGallery: req.body.NameOfGallery, GalleryStake: req.body.GalleryStake },
        errorMessage: 'A gallery with this name already exists.'
      });
    }
    next(error);
  }
});

router.post('/:id/delete', requireAuth, async (req, res, next) => {
  try {
    const galleryId = req.params.id;
    const galleryToDelete = await db.Gallery.findByPk(galleryId);

    if (!galleryToDelete) {
      return res.status(404).render('error', { message: 'Gallery not found for deletion.', error: { status: 404 }});
    }

    await galleryToDelete.destroy();
    res.redirect('/galleries?message=Gallery+deleted+successfully');
  } catch (error) {
    next(error);
  }
});

module.exports = router;