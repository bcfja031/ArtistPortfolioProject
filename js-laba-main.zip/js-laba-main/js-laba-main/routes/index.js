var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Welcome to Art Gallery', user: req.user });
});

router.get('/login', function(req, res, next) {
  if (req.user) {
    return res.redirect('/users');
  }
  const returnTo = req.query.returnTo || req.session.returnTo;
  res.render('login', { title: 'Login', error: req.query.error, returnTo: returnTo });
});

router.get('/register', function(req, res, next) {
  if (req.user) {
    return res.redirect('/users');
  }
  const returnTo = req.query.returnTo || req.session.returnTo;
  res.render('register', { title: 'Register', error: req.query.error, returnTo: returnTo }); 
});

router.post('/logout', (req, res) => {
  const returnTo = req.body.returnTo ? decodeURIComponent(req.body.returnTo) : '/';
  res.clearCookie('token');
  res.redirect(returnTo);
});

module.exports = router;
