const express = require('express');
const router = express.Router();
const db = require('../models');
const createError = require('http-errors');
const { requireAuth } = require('../middleware/authMiddleware');


router.get('/', async (req, res, next) => {
  try {
    const journals = await db.Journal.findAll({
      order: [['NameOfJournal', 'ASC']]
    });

    console.log('Journals fetched for index view:', journals.map(journal => journal.get({ plain: true })));

    res.render('journals/index', {
      title: 'Journals List',
      journals: journals,
      user: req.user,
      query: req.query
    });
  } catch (error) {
    console.error('Error fetching journals:', error);
    next(error);
  }
});

router.get('/new', requireAuth, (req, res) => {
  res.render('journals/new', {
    title: 'Add New Journal',
    user: req.user,
    journal: {},
    errors: []
  });
});

router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { NameOfJournal, JournalRequirements, JournalStake } = req.body;

    const errors = [];
    if (!NameOfJournal || NameOfJournal.trim() === '') {
       errors.push({ message: 'Journal name is required.' });
    }

    if (errors.length > 0) {
        return res.render('journals/new', {
            title: 'Add New Journal',
            user: req.user,
            journal: req.body,
            errors: errors
        });
    }

    const newJournal = await db.Journal.create({
      NameOfJournal: NameOfJournal.trim(),
      JournalRequirements: JournalRequirements ? JournalRequirements.trim() : null,
      JournalStake: JournalStake ? JournalStake.trim() : null
    });

    res.redirect('/journals?message=Journal+created+successfully');
  } catch (error) {
    console.error('Error creating journal:', error);
    let errorMessage = 'Error creating journal. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'A journal with this name already exists.';
    }

    res.render('journals/new', {
      title: 'Add New Journal',
      user: req.user,
      journal: req.body,
      errors: [{ message: errorMessage }]
    });
  }
});

router.get('/:id/edit', requireAuth, async (req, res, next) => {
  try {
    const journal = await db.Journal.findByPk(req.params.id);
    if (!journal) {
      return res.status(404).render('error', { message: 'Journal not found', error: { status: 404 } });
    }
    res.render('journals/edit', {
      title: 'Edit Journal',
      journal: journal,
      errors: [],
      user: req.user
    });
  } catch (error) {
    console.error('Error fetching journal for edit:', error);
    next(error);
  }
});

router.post('/:id/update', requireAuth, async (req, res, next) => {
  try {
    const journalId = req.params.id;
    const { NameOfJournal, JournalRequirements, JournalStake } = req.body;

    const journalToUpdate = await db.Journal.findByPk(journalId);

    if (!journalToUpdate) {
      return res.status(404).render('error', { message: 'Journal not found for update.', error: { status: 404 }});
    }

    const errors = [];
    if (!NameOfJournal || NameOfJournal.trim() === '') {
      errors.push({ message: 'Journal Name is required.' });
    }

    if (errors.length > 0) {
        return res.render('journals/edit', {
            title: 'Edit Journal',
            journal: { ...journalToUpdate.get({ plain: true }), NameOfJournal, JournalRequirements, JournalStake },
            errors: errors,
            user: req.user
        });
    }

    journalToUpdate.NameOfJournal = NameOfJournal.trim();
    journalToUpdate.JournalRequirements = JournalRequirements ? JournalRequirements.trim() : null;
    journalToUpdate.JournalStake = JournalStake ? JournalStake.trim() : null;

    await journalToUpdate.save();
    res.redirect('/journals?message=Journal+updated+successfully');
  } catch (error) {
    console.error('Error updating journal:', error);
    let errorMessage = 'Error updating journal. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'A journal with this name already exists.';
    }

    try {
        const journal = await db.Journal.findByPk(req.params.id);
        res.render('journals/edit', {
           title: 'Edit Journal',
           journal: { ...journal.get({ plain: true }), NameOfJournal: req.body.NameOfJournal, JournalRequirements: req.body.JournalRequirements, JournalStake: req.body.JournalStake },
           errors: [{ message: errorMessage }],
           user: req.user
         });
    } catch (fetchError) {
        console.error('Error fetching data after update error:', fetchError);
        next(error);
    }
  }
});

router.post('/:id/delete', requireAuth, async (req, res, next) => {
  try {
    const journalId = req.params.id;
    const journalToDelete = await db.Journal.findByPk(journalId);

    if (!journalToDelete) {
      return res.status(404).render('error', { message: 'Journal not found for deletion.', error: { status: 404 }});
    }

    await journalToDelete.destroy();
    res.redirect('/journals?message=Journal+deleted+successfully');
  } catch (error) {
    console.error('Error deleting journal:', error);
    next(error);
  }
});

module.exports = router;