const express = require('express');
const router = express.Router();
const db = require('../models'); 
const createError = require('http-errors');
const { requireAuth } = require('../middleware/authMiddleware'); 

// GET all merch
router.get('/', async (req, res, next) => {
  try {
    const merchItems = await db.Merch.findAll({
      include: [{ model: db.Gallery, as: 'gallery' }], 
      order: [['NameOfMerch', 'ASC']] 
    });

    res.render('merch/index', {
      title: 'Merchandise List',
      merchItems: merchItems,
      user: req.user, 
      query: req.query 
    });
  } catch (error) {
    next(error);
  }
});

router.get('/new', requireAuth, async (req, res) => {
  try {
    const galleries = await db.Gallery.findAll();
    res.render('merch/new', {
      title: 'Add New Merchandise Item',
      user: req.user,
      merch: {}, 
      errors: [], 
      galleries: galleries
    });
  } catch (error) {
    console.error('Error fetching data for new merch form:', error);
    res.render('merch/new', {
      title: 'Add New Merchandise Item',
      user: req.user,
      merch: {},
      errors: [{ message: 'Could not load required data for the form.' }],
      galleries: []
    });
  }
});

router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { NameOfMerch, TypeOfMerch, ConditionMerch, Price, IDGallery } = req.body;

    const errors = [];
    if (!NameOfMerch || NameOfMerch.trim() === '') {
       errors.push({ message: 'Merchandise name is required.' });
    }
    if (!Price || isNaN(Price) || parseFloat(Price) < 0) {
        errors.push({ message: 'Valid price is required.' });
    }
    if (!IDGallery) {
        errors.push({ message: 'Gallery is required.' });
    }

    if (errors.length > 0) {
        const galleries = await db.Gallery.findAll();
        return res.render('merch/new', {
            title: 'Add New Merchandise Item',
            user: req.user,
            merch: req.body,
            errors: errors,
            galleries: galleries
        });
    }

    const newMerch = await db.Merch.create({
      NameOfMerch: NameOfMerch.trim(),
      TypeOfMerch: TypeOfMerch ? TypeOfMerch.trim() : null,
      ConditionMerch: ConditionMerch ? ConditionMerch.trim() : null,
      Price: parseFloat(Price),
      IDGallery: IDGallery
    });

    res.redirect('/merch?message=Merchandise+item+created+successfully');
  } catch (error) {
    console.error('Error creating merch item:', error);
    let errorMessage = 'Error creating merchandise item. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'A merchandise item with this name already exists (if unique constraint is set).'; // Adjust if unique constraint is on NameOfMerch
    }

    try {
        const galleries = await db.Gallery.findAll();
        res.render('merch/new', {
          title: 'Add New Merchandise Item',
          user: req.user,
          merch: req.body,
          errors: [{ message: errorMessage }],
          galleries: galleries
        });
    } catch (fetchError) {
        console.error('Error fetching data after creation error:', fetchError);
        next(error);
    }
  }
});

router.get('/:id/edit', requireAuth, async (req, res, next) => {
  try {
    const merchItem = await db.Merch.findByPk(req.params.id);
    if (!merchItem) {
      return res.status(404).render('error', { message: 'Merchandise item not found', error: { status: 404 } });
    }
    const galleries = await db.Gallery.findAll();
    res.render('merch/edit', {
      title: 'Edit Merchandise Item',
      merch: merchItem,
      errors: [],
      user: req.user,
      galleries: galleries
    });
  } catch (error) {
    next(error);
  }
});

router.post('/:id/update', requireAuth, async (req, res, next) => {
  try {
    const merchId = req.params.id;
    const { NameOfMerch, TypeOfMerch, ConditionMerch, Price, IDGallery } = req.body;

    const merchItemToUpdate = await db.Merch.findByPk(merchId);

    if (!merchItemToUpdate) {
      return res.status(404).render('error', { message: 'Merchandise item not found for update.', error: { status: 404 }});
    }

    const errors = [];
    if (!NameOfMerch || NameOfMerch.trim() === '') {
      errors.push({ message: 'Merchandise Name is required.' });
    }
    if (!Price || isNaN(Price) || parseFloat(Price) < 0) {
        errors.push({ message: 'Valid price is required.' });
    }
    if (!IDGallery) {
        errors.push({ message: 'Gallery is required.' });
    }

    if (errors.length > 0) {
        const galleries = await db.Gallery.findAll();
        return res.render('merch/edit', {
            title: 'Edit Merchandise Item',
            merch: { ...merchItemToUpdate.get({ plain: true }), NameOfMerch, TypeOfMerch, ConditionMerch, Price, IDGallery },
            errors: errors,
            user: req.user,
            galleries: galleries
        });
    }

    merchItemToUpdate.NameOfMerch = NameOfMerch.trim();
    merchItemToUpdate.TypeOfMerch = TypeOfMerch ? TypeOfMerch.trim() : null;
    merchItemToUpdate.ConditionMerch = ConditionMerch ? ConditionMerch.trim() : null;
    merchItemToUpdate.Price = parseFloat(Price);
    merchItemToUpdate.IDGallery = IDGallery;

    await merchItemToUpdate.save();
    res.redirect('/merch?message=Merchandise+item+updated+successfully');
  } catch (error) {
    console.error('Error updating merch item:', error);
    let errorMessage = 'Error updating merchandise item. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'A merchandise item with this name already exists (if unique constraint is set).'; // Adjust if unique constraint is on NameOfMerch
    }

    try {
        const galleries = await db.Gallery.findAll();
        res.render('merch/edit', {
           title: 'Edit Merchandise Item',
           merch: { ...merchItemToUpdate.get({ plain: true }), NameOfMerch: req.body.NameOfMerch, TypeOfMerch: req.body.TypeOfMerch, ConditionMerch: req.body.ConditionMerch, Price: req.body.Price, IDGallery: req.body.IDGallery },
           errors: [{ message: errorMessage }],
           user: req.user,
           galleries: galleries
         });
    } catch (fetchError) {
        console.error('Error fetching data after update error:', fetchError);
        next(error);
    }
  }
});

router.post('/:id/delete', requireAuth, async (req, res, next) => {
  try {
    const merchId = req.params.id;
    const merchItemToDelete = await db.Merch.findByPk(merchId);

    if (!merchItemToDelete) {
      return res.status(404).render('error', { message: 'Merchandise item not found for deletion.', error: { status: 404 }});
    }

    await merchItemToDelete.destroy();
    res.redirect('/merch?message=Merchandise+item+deleted+successfully');
  } catch (error) {
    console.error('Error deleting merch item:', error);
    next(error);
  }
});

module.exports = router;