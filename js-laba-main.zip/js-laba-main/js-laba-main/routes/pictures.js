const express = require('express');
const router = express.Router();
const db = require('../models');

router.get('/', async (req, res, next) => {
  try {
    const pictures = await db.Picture.findAll({
      include: [{
        model: db.Artist,
        as: 'artist',
        attributes: ['FullNameArtist']
      }],
      order: [['IDPicture', 'ASC']]
    });
    res.render('pictures/index', { 
      title: 'Pictures List',
      pictures: pictures,
      user: req.user
    });
  } catch (error) {
    console.error('Error fetching pictures:', error);
    next(error);
  }
});

router.get('/new', async (req, res, next) => {
  console.log('Accessed /pictures/new route');
  try {
    const artists = await db.Artist.findAll({
      order: [['FullNameArtist', 'ASC']]
    });
    res.render('pictures/new', {
      title: 'Add New Picture',
      artists: artists,
      user: req.user,
      currentData: {}
    });
  } catch (error) {
    console.error('Error fetching artists for new picture form:', error);
    next(error);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const {
      NameOfPicture,
      IDArtist,
      YearOfDrawing,
      Price,
      StyleOfDrawing,
      Materials,
      ConditionPictures,
      DescriptionOfPicture
    } = req.body;

    if (!NameOfPicture || !IDArtist) {
      const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
      return res.render('pictures/new', {
        title: 'Add New Picture',
        artists: artists,
        user: req.user,
        currentData: req.body,
        errors: [{ message: 'Picture Name and Artist are required.' }]
      });
    }

    const newPicture = await db.Picture.create({
      NameOfPicture,
      IDArtist,
      YearOfDrawing: YearOfDrawing || null,
      Price: Price || null,
      StyleOfDrawing: StyleOfDrawing || null,
      Materials: Materials || null,
      ConditionPictures: ConditionPictures || null,
      DescriptionOfPicture: DescriptionOfPicture || null
    });

    res.redirect('/pictures');

  } catch (error) {
    console.error('Error creating picture:', error);
    if (error.name === 'SequelizeValidationError') {
      const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
      return res.render('pictures/new', {
        title: 'Add New Picture',
        artists: artists,
        user: req.user,
        currentData: req.body,
        errors: error.errors
      });
    }
    next(error);
  }
});

router.get('/:id/edit', async (req, res, next) => {
  try {
    const pictureId = req.params.id;
    const picture = await db.Picture.findByPk(pictureId);

    if (!picture) {
      return next(createError(404, 'Picture not found'));
    }

    const artists = await db.Artist.findAll({
      order: [['FullNameArtist', 'ASC']]
    });

    res.render('pictures/edit', {
      title: 'Edit Picture',
      picture: picture,
      artists: artists,
      currentData: picture,
      user: req.user
    });

  } catch (error) {
    console.error('Error fetching picture for edit:', error);
    next(error);
  }
});

router.post('/:id', async (req, res, next) => {
  try {
    const pictureId = req.params.id;
    const pictureToUpdate = await db.Picture.findByPk(pictureId);

    if (!pictureToUpdate) {
      return next(createError(404, 'Picture not found for update'));
    }

    const {
      NameOfPicture,
      IDArtist,
      YearOfDrawing,
      Price,
      StyleOfDrawing,
      Materials,
      ConditionPictures,
      DescriptionOfPicture
    } = req.body;

    if (!NameOfPicture || !IDArtist) {
      const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
      return res.render('pictures/edit', {
        title: 'Edit Picture',
        picture: pictureToUpdate,
        artists: artists,
        currentData: req.body,
        errors: [{ message: 'Picture Name and Artist are required.' }],
        user: req.user
      });
    }

    await pictureToUpdate.update({
      NameOfPicture,
      IDArtist,
      YearOfDrawing: YearOfDrawing || null,
      Price: Price || null,
      StyleOfDrawing: StyleOfDrawing || null,
      Materials: Materials || null,
      ConditionPictures: ConditionPictures || null,
      DescriptionOfPicture: DescriptionOfPicture || null
    });

    res.redirect('/pictures');

  } catch (error) {
    console.error('Error updating picture:', error);
    if (error.name === 'SequelizeValidationError') {
      const pictureId = req.params.id;
      const picture = await db.Picture.findByPk(pictureId);
      const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
      return res.render('pictures/edit', {
        title: 'Edit Picture',
        picture: picture,
        artists: artists,
        currentData: req.body,
        errors: error.errors,
        user: req.user
      });
    }
    next(error);
  }
});

router.post('/:id/delete', async (req, res, next) => {
  try {
    const pictureId = req.params.id;
    const pictureToDelete = await db.Picture.findByPk(pictureId);

    if (!pictureToDelete) {
      return res.redirect('/pictures');
    }

    await pictureToDelete.destroy();

    res.redirect('/pictures');

  } catch (error) {
    console.error('Error deleting picture:', error);
    next(error);
  }
});

module.exports = router;