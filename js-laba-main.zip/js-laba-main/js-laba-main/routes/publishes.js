const express = require('express');
const router = express.Router();
const db = require('../models');
const createError = require('http-errors');
const { requireAuth } = require('../middleware/authMiddleware');

router.get('/', async (req, res, next) => {
  try {
    const publishes = await db.Publishes.findAll({
      include: [
        { model: db.Artist, as: 'artist', attributes: ['FullNameArtist'] },
        { model: db.Journal, as: 'journal', attributes: ['NameOfJournal'] }
      ],
      order: [[{ model: db.Artist, as: 'artist' }, 'FullNameArtist', 'ASC']]
    });

    res.render('publishes/index', {
      title: 'Publishes List',
      publishes: publishes,
      user: req.user,
      query: req.query
    });
  } catch (error) {
    console.error('Error fetching publishes:', error);
    next(error);
  }
});

router.get('/new', requireAuth, async (req, res) => {
  try {
    const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
    const journals = await db.Journal.findAll({ order: [['NameOfJournal', 'ASC']] });
    res.render('publishes/new', {
      title: 'Add New Publish Record',
      user: req.user,
      publish: {},
      errors: [],
      artists: artists,
      journals: journals
    });
  } catch (error) {
    console.error('Error fetching data for new publish form:', error);
    res.render('publishes/new', {
      title: 'Add New Publish Record',
      user: req.user,
      publish: {},
      errors: [{ message: 'Could not load required data for the form.' }],
      artists: [],
      journals: []
    });
  }
});


router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { IDArtist, IDJournal } = req.body;

    const errors = [];
    if (!IDArtist) {
       errors.push({ message: 'Artist is required.' });
    }
    if (!IDJournal) {
        errors.push({ message: 'Journal is required.' });
    }

    if (errors.length > 0) {
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        const journals = await db.Journal.findAll({ order: [['NameOfJournal', 'ASC']] });
        return res.render('publishes/new', {
            title: 'Add New Publish Record',
            user: req.user,
            publish: req.body,
            errors: errors,
            artists: artists,
            journals: journals
        });
    }

    const newPublish = await db.Publishes.create({
      IDArtist: IDArtist,
      IDJournal: IDJournal
    });

    res.redirect('/publishes?message=Publish+record+created+successfully');
  } catch (error) {
    console.error('Error creating publish record:', error);
    let errorMessage = 'Error creating publish record. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'This publish record already exists.';
    }

    try {
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        const journals = await db.Journal.findAll({ order: [['NameOfJournal', 'ASC']] });
        res.render('publishes/new', {
          title: 'Add New Publish Record',
          user: req.user,
          publish: req.body,
          errors: [{ message: errorMessage }],
          artists: artists,
          journals: journals
        });
    } catch (fetchError) {
        console.error('Error fetching data after creation error:', fetchError);
        next(error);
    }
  }
});

router.get('/:artistId/:journalId/edit', requireAuth, async (req, res, next) => {
  try {
    const { artistId, journalId } = req.params;
    console.log(`Attempting to edit publish with Artist ID: ${artistId}, Journal ID: ${journalId}`);

    const publish = await db.Publishes.findOne({
      where: { IDArtist: artistId, IDJournal: journalId }
    });

    if (!publish) {
      console.log('Publish record not found for edit.');
      return next(createError(404, 'Publish record not found.'));
    }

    const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
    const journals = await db.Journal.findAll({ order: [['NameOfJournal', 'ASC']] });

    res.render('publishes/edit', {
      title: 'Edit Publish',
      user: req.user,
      publish: publish,
      errors: [],
      artists: artists,
      journals: journals
    });
  } catch (error) {
    console.error('Error fetching data for edit publish form:', error);
    next(error);
  }
});

router.post('/:artistId/:journalId', requireAuth, async (req, res, next) => {
  try {
    const { artistId, journalId } = req.params;
    console.log(`Attempting to update publish record with Artist ID: ${artistId}, Journal ID: ${journalId}`);
    const { IDArtist, IDJournal } = req.body;

    const publishToUpdate = await db.Publishes.findOne({
      where: { IDArtist: artistId, IDJournal: journalId }
    });

    if (!publishToUpdate) {
      console.log('Publish record not found for update.');
      return next(createError(404, 'Publish record not found for update.'));
    }

    const errors = [];
    if (!IDArtist) {
       errors.push({ message: 'Artist is required.' });
    }
    if (!IDJournal) {
        errors.push({ message: 'Journal is required.' });
    }

    if (errors.length > 0) {
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        const journals = await db.Journal.findAll({ order: [['NameOfJournal', 'ASC']] });
        const publish = await db.Publishes.findOne({
           where: { IDArtist: artistId, IDJournal: journalId }
        });
        return res.render('publishes/edit', {
            title: 'Edit Publish',
            user: req.user,
            publish: publish,
            errors: errors,
            artists: artists,
            journals: journals
        });
    }

    await publishToUpdate.update({
      IDArtist: IDArtist,
      IDJournal: IDJournal
    });

    res.redirect('/publishes?message=Publish+record+updated+successfully');
  } catch (error) {
    console.error('Error updating publish record:', error);
    let errorMessage = 'Error updating publish record. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'This publish record already exists.';
    }

    try {
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        const journals = await db.Journal.findAll({ order: [['NameOfJournal', 'ASC']] });
        const publish = await db.Publishes.findOne({
           where: { IDArtist: req.params.artistId, IDJournal: req.params.journalId }
        });
        res.render('publishes/edit', {
          title: 'Edit Publish',
          user: req.user,
          publish: publish,
          errors: [{ message: errorMessage }],
          artists: artists,
          journals: journals
        });
    } catch (fetchError) {
        console.error('Error fetching data after update error:', fetchError);
        next(error);
    }
  }
});


router.post('/:artistId/:journalId/delete', requireAuth, async (req, res, next) => {
  try {
    const { artistId, journalId } = req.params;
    console.log(`Attempting to delete publish record with Artist ID: ${artistId}, Journal ID: ${journalId}`);

    const publishToDelete = await db.Publishes.findOne({
      where: { IDArtist: artistId, IDJournal: journalId }
    });

    if (!publishToDelete) {
      console.log('Publish record not found for deletion.');
      return res.status(404).render('error', { message: 'Publish record not found for deletion.', error: { status: 404 }});
    }

    await publishToDelete.destroy();
    res.redirect('/publishes?message=Publish+record+deleted+successfully');
  } catch (error) {
    console.error('Error deleting publish record:', error);
    next(error);
  }
});


module.exports = router;