const express = require('express');
const router = express.Router();
const db = require('../models');
const createError = require('http-errors');
const { requireAuth } = require('../middleware/authMiddleware');

router.get('/', async (req, res, next) => {
  try {
    const reviews = await db.Review.findAll({
      include: [
        { model: db.Client, as: 'client', attributes: ['FullNameClient'] },
        { model: db.Artist, as: 'artist', attributes: ['FullNameArtist'] }
      ],
    });

    res.render('reviews/index', {
      title: 'Reviews List',
      reviews: reviews,
      user: req.user,
      query: req.query
    });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    next(error);
  }
});

router.get('/new', requireAuth, async (req, res) => {
  try {
    // Fetch Clients and Artists to populate dropdowns in the form
    // Corrected order attribute name
    const clients = await db.Client.findAll({ order: [['FullNameClient', 'ASC']] });
    const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
    res.render('reviews/new', {
      title: 'Add New Review',
      user: req.user,
      review: {}, // Empty object for new form
      errors: [], // For validation errors
      clients: clients,
      artists: artists
    });
  } catch (error) {
    console.error('Error fetching data for new review form:', error);
    res.render('reviews/new', {
      title: 'Add New Review',
      user: req.user,
      review: {},
      errors: [{ message: 'Could not load required data for the form.' }],
      clients: [],
      artists: []
    });
  }
});

// POST create new review
router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { Comment, IDClient, IDArtist } = req.body;

    // Basic validation
    const errors = [];
    if (!IDClient) {
       errors.push({ message: 'Client is required.' });
    }
    if (!IDArtist) {
        errors.push({ message: 'Artist is required.' });
    }

    if (errors.length > 0) {
        // Fetch clients and artists again to re-render the form with errors
        // Corrected order attribute name
        const clients = await db.Client.findAll({ order: [['FullNameClient', 'ASC']] });
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        return res.render('reviews/new', {
            title: 'Add New Review',
            user: req.user,
            review: req.body, // Pass submitted data back to the form
            errors: errors,
            clients: clients,
            artists: artists
        });
    }

    const newReview = await db.Review.create({
      Comment: Comment ? Comment.trim() : null,
      IDClient: IDClient,
      IDArtist: IDArtist
    });

    res.redirect('/reviews?message=Review+created+successfully');
  } catch (error) {
    console.error('Error creating review:', error);
    let errorMessage = 'Error creating review. Please try again.';

    // Check if the error is a unique constraint violation (if applicable)
    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'This review already exists.'; // Adjust if unique constraint is different
    }

    // Fetch clients and artists again to re-render the form with the error
    try {
        // Corrected order attribute name
        const clients = await db.Client.findAll({ order: [['FullNameClient', 'ASC']] });
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        res.render('reviews/new', {
          title: 'Add New Review',
          user: req.user,
          review: req.body, // Pass submitted data back
          errors: [{ message: errorMessage }], // Pass the specific or generic error message
          clients: clients,
          artists: artists
        });
    } catch (fetchError) {
        console.error('Error fetching data after creation error:', fetchError);
        next(error); // Pass original error if fetching fails
    }
  }
});

// GET form to edit review
router.get('/:id/edit', requireAuth, async (req, res, next) => {
  try {
    const review = await db.Review.findByPk(req.params.id); // Find by primary key
    if (!review) {
      return res.status(404).render('error', { message: 'Review not found', error: { status: 404 } });
    }
    // Fetch Clients and Artists for dropdowns here too
    // Corrected order attribute name
    const clients = await db.Client.findAll({ order: [['FullNameClient', 'ASC']] });
    const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
    res.render('reviews/edit', {
      title: 'Edit Review',
      review: review,
      errors: [],
      user: req.user,
      clients: clients,
      artists: artists
    });
  } catch (error) {
    console.error('Error fetching review for edit:', error);
    next(error);
  }
});

// POST update review
router.post('/:id/update', requireAuth, async (req, res, next) => {
  try {
    const reviewId = req.params.id;
    const { Comment, IDClient, IDArtist } = req.body;

    const reviewToUpdate = await db.Review.findByPk(reviewId);

    if (!reviewToUpdate) {
      return res.status(404).render('error', { message: 'Review not found for update.', error: { status: 404 }});
    }

    // Basic validation
    const errors = [];
    if (!IDClient) {
      errors.push({ message: 'Client is required.' });
    }
    if (!IDArtist) {
        errors.push({ message: 'Artist is required.' });
    }

    if (errors.length > 0) {
        // Fetch clients and artists again to re-render the form with errors
        // Corrected order attribute name
        const clients = await db.Client.findAll({ order: [['FullNameClient', 'ASC']] });
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        return res.render('reviews/edit', {
            title: 'Edit Review',
            review: { ...reviewToUpdate.get({ plain: true }), Comment, IDClient, IDArtist }, // Merge original data with submitted data
            errors: errors,
            user: req.user,
            clients: clients,
            artists: artists
        });
    }

    reviewToUpdate.Comment = Comment ? Comment.trim() : null;
    reviewToUpdate.IDClient = IDClient;
    reviewToUpdate.IDArtist = IDArtist;

    await reviewToUpdate.save();
    res.redirect('/reviews?message=Review+updated+successfully');
  } catch (error) {
    console.error('Error updating review:', error);
    let errorMessage = 'Error updating review. Please try again.';

    if (error.name === 'SequelizeUniqueConstraintError') {
        errorMessage = 'This review already exists.'; // Adjust if unique constraint is different
    }

    try {
        const review = await db.Review.findByPk(req.params.id);
        // Corrected order attribute name
        const clients = await db.Client.findAll({ order: [['FullNameClient', 'ASC']] });
        const artists = await db.Artist.findAll({ order: [['FullNameArtist', 'ASC']] });
        res.render('reviews/edit', {
           title: 'Edit Review',
           review: { ...review.get({ plain: true }), Comment: req.body.Comment, IDClient: req.body.IDClient, IDArtist: req.body.IDArtist },
           errors: [{ message: errorMessage }],
           user: req.user,
           clients: clients,
           artists: artists
         });
    } catch (fetchError) {
        console.error('Error fetching data after update error:', fetchError);
        next(error); // Pass original error if fetching fails
    }
  }
});

// POST delete review
router.post('/:id/delete', requireAuth, async (req, res, next) => {
  try {
    const reviewId = req.params.id;
    const reviewToDelete = await db.Review.findByPk(reviewId);

    if (!reviewToDelete) {
      return res.status(404).render('error', { message: 'Review not found for deletion.', error: { status: 404 }});
    }

    await reviewToDelete.destroy();
    res.redirect('/reviews?message=Review+deleted+successfully');
  } catch (error) {
    console.error('Error deleting review:', error);
    next(error);
  }
});

module.exports = router;