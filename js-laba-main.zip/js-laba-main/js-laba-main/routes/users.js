var express = require('express');
var router = express.Router();
const jwt = require('jsonwebtoken');
const { requireAuth } = require('../middleware/authMiddleware');
const db = require('../models');
const bcrypt = require('bcrypt');

router.post('/register', async (req, res) => {
  try {
    const { login, password, returnTo } = req.body;
    if (!login || !password) {
      return res.status(400).send('Login and password are required. <a href="/users">Back</a>');
    }
    const existingUser = await db.User.findOne({ where: { login } });
    if (existingUser) {
      return res.status(400).send('User with this login already exists. <a href="/users">Back</a>');
    }
    const user = await db.User.create({ login, password });
    res.redirect(`/login?returnTo=${returnTo || '/users'}`);
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).send('Error during registration. <a href="/users">Back</a>');
  }
});

router.post('/login', async (req, res) => {
  const { login, password, returnTo: bodyReturnTo } = req.body; 
  try {
    const user = await db.User.findOne({ where: { login } });
    if (user && await bcrypt.compare(password, user.password)) {
      const token = jwt.sign(
        { id: user.id, login: user.login },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN }
      );

      res.cookie('token', token, {
          httpOnly: true,
          secure: process.env.NODE_ENV === 'production',
          sameSite: 'lax',
          path: '/',
        });

      const returnTo = bodyReturnTo || req.session.returnTo || '/users';
      delete req.session.returnTo;

      res.redirect(returnTo);
    } else {
      res.render('login', { error: 'Invalid login or password', returnTo: bodyReturnTo || req.session.returnTo });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.render('login', { error: 'An error occurred during login', returnTo: bodyReturnTo || req.session.returnTo });
  }
});

router.get('/', requireAuth, async function(req, res, next) {
  try {
    const users = await db.User.findAll({ attributes: { exclude: ['password'] } });
    res.render('users/index', { title: 'User Management', users: users, currentUser: req.user });
  } catch (error) {
    console.error(error);
    next(error);
  }
});

router.get('/:id/edit', requireAuth, async (req, res, next) => {
  try {
    const user = await db.User.findByPk(req.params.id);
    if (!user) {
      return res.status(404).send('User not found. <a href="/users">Back</a>');
    }
    res.render('users/edit', { title: 'Edit User', user: user, currentUser: req.user });
  } catch (error) {
    console.error(error);
    next(error);
  }
});

router.post('/:id/update', requireAuth, async (req, res, next) => {
  try {
    const userId = req.params.id;
    const { login, password } = req.body;
    const userToUpdate = await db.User.findByPk(userId);

    if (!userToUpdate) {
      return res.status(404).send('User not found for update. <a href="/users">Back</a>');
    }

    userToUpdate.login = login;
    if (password) {
      userToUpdate.password = password;
    }
    await userToUpdate.save();
    res.redirect('/users');
  } catch (error) {
    console.error('Update error:', error);
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).send('Login already exists. <a href="/users">Back</a>');
    }
    next(error);
  }
});

router.post('/:id/delete', requireAuth, async (req, res, next) => {
  try {
    const userId = req.params.id;
    const userToDelete = await db.User.findByPk(userId);
    if (!userToDelete) {
      return res.status(404).send('User not found for deletion. <a href="/users">Back</a>');
    }
    
    await userToDelete.destroy();
    res.redirect('/users');
  } catch (error) {
    console.error('Delete error:', error);
    next(error);
  }
});

router.get('/new', requireAuth, (req, res) => {
  res.render('users/new', {
    title: 'Add New User',
    user: req.user,
    errors: []
  });
});

module.exports = router;
